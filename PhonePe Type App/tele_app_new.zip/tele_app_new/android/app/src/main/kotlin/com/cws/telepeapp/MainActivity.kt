package com.cws.telepeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
